//Functions - Anonymous Functions



var calcArea = function(width, height){
    var area = width * height;
    return area;
}

var a = calcArea(20,30);

console.log(a);